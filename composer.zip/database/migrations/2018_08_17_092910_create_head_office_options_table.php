<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateHeadOfficeOptionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('head_office_options', function (Blueprint $table) {
            $table->bigIncrements('HOID');
            $table->string('HOSNAME');
            $table->string('HOSADDRESS');
            $table->string('HOSADDRESS2');
            $table->string('HOCITY');
            $table->string('HOSTATE');
            $table->string('HOCOUNTRY');
            $table->string('HOPOSTAL_CODE');
            $table->string('HOPHONE1');
            $table->string('HOPHONE2');
            $table->string('HOPHONE3');
            $table->string('HOPHONE4');
            $table->string('HOEMAIL');
            $table->blob('HOLOGO');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('head_office_options');
    }
}
