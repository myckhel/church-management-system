<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class members_attendance extends Model
{
    //
}
