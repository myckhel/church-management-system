<?php $__env->startSection('title'); ?> Collections Report <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--CONTENT CONTAINER-->
<!--===================================================-->
<div id="content-container">
    <div id="page-head">

        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Collections Report</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->

        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
            <li>
                <a href="forms-general.html#">
                    <i class="demo-pli-home"></i>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('attendance')); ?>">Reports</a>
            </li>
            <li class="active">Collections</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->

    </div>


    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="col-md-6 col-md-offset-3"  >
                <?php if(session('status')): ?>

                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="alert alert-danger"><?php echo e($error); ?></div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>
            </div>
            <div class="col-md-6 col-md-offset-2" style="margin-bottom:20px">
              <div class="panel">
                  <div class="panel-heading">
                      <h3 class="panel-title"><strong>Collections <i>Report Counts</i> For</strong></h3>
                  </div>
                <div class="panel-body">
                  <ul>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Total No Of All Collections Till Date
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->total_collections)); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Total No Of All Today's Collections
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->todays_collections)); ?></span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div class="col-md-6 col-md-offset-2" style="margin-bottom:20px">
              <div class="panel">
                  <div class="panel-heading">
                      <h3 class="panel-title"><strong>Total <i>Collections</i> By Collections Type Till Date</strong></h3>
                  </div>
                <div class="panel-body">
                  <ul>
                    <li class="bg-warning list-group-item d-flex justify-content-between align-items-center">
                      Collection Type
                      <span class="badge badge-primary badge-pill">Collection Type Total</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Special Offering
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->so)); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Seed Offering
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->sdo)); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Offering
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->o)); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Donation
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->d)); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Tithe
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->t)); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      First Fruit
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->ff)); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Covenant Seed
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->cs)); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Love Seed
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->ls)); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Sacrifice
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->s)); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Thanksgiving
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->tg)); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Thanksgiving Seed
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->tgs)); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      Other
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->ot)); ?></span>
                    </li>
                    <li class="bg-success list-group-item d-flex justify-content-between align-items-center">
                      Total
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($reports[0]->total)); ?></span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div class="col-md-6 col-md-offset-2" style="margin-bottom:20px">
              <div class="panel">
                  <div class="panel-heading">
                      <h3 class="panel-title"><strong>Total Collections <i>By</i> Members Till Date</strong></h3>
                  </div>
                <div class="panel-body">
                  <ul>
                    <li class="bg-warning list-group-item d-flex justify-content-between align-items-center">
                      Member Name
                      <span class="badge badge-primary badge-pill">Member Total</span>
                    </li>
                    <?php $total = 0; ?>
                    <?php $__currentLoopData = $m_r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $total += $mc->total; ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      <?php echo e($mc->fname); ?> <?php echo e($mc->lname); ?>

                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($mc->total)); ?></span>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="bg-success list-group-item d-flex justify-content-between align-items-center">
                      Total
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($total)); ?></span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <?php if(\Auth::user()->isAdmin()): ?>
            <div class="col-md-6 col-md-offset-2" style="margin-bottom:20px">
              <div class="panel">
                  <div class="panel-heading">
                      <h3 class="panel-title"><strong>Total Branches <i>By</i> Collections Till Date</strong></h3>
                  </div>
                <div class="panel-body">
                  <ul>
                    <li class="bg-warning list-group-item d-flex justify-content-between align-items-center">
                      Branch Name
                      <span class="badge badge-primary badge-pill">Branch Total</span>
                    </li>
                    <?php $total = 0; ?>
                    <?php $__currentLoopData = $ad_rep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $total += ($ar->ctotal + $ar->mtotal); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      <?php echo e($ar->name); ?>

                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($ar->ctotal + $ar->mtotal)); ?></span>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="bg-success list-group-item d-flex justify-content-between align-items-center">
                      Total
                      <span class="badge badge-primary badge-pill">N <?php echo e(number_format($total)); ?></span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<!--===================================================-->
<!--END CONTENT CONTAINER-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>