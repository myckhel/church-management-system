<?php $__env->startSection('title'); ?> All groups <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--CONTENT CONTAINER-->
<!--===================================================-->
<div id="content-container">
    <div id="page-head">

        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">group</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->


        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
            <li>
                <a href="forms-general.html#">
                    <i class="demo-pli-home"></i>
                </a>
            </li>
            <li>
                <a href="forms-general.html#">groups</a>
            </li>
            <li class="active">All</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->

    </div>


    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
    <?php if(session('status')): ?>
            <!-- Line Chart -->
            <!---------------------------------->
            <div class="panel">
                <div class="panel-heading">
                </div>
                <div class="pad-all">
                <?php if(session('status')): ?>

                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(count($errors) > 0): ?> 
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="alert alert-danger"><?php echo e($error); ?></div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    
                <?php endif; ?> 

                </div>
            </div>
            <!---------------------------------->
        <?php endif; ?> 

        <!-- Line Chart -->
        <!---------------------------------->
        <div class="panel" style="padding-top:15px;padding-bottom:45px;">
            <div class="panel-heading">
                <h3 class="panel-title">Create Group</h3>
            </div>
            <div class="pad-all">
            <form method="POST" action="<?php echo e(route('group.create')); ?>">
            <?php echo csrf_field(); ?>
            <input type=text name=branch_id value="<?php echo e(\Auth::user()->branchcode); ?>" hidden=hidden/>
            <input style="border:1px solid #ddd; padding:7px;outline:none" name=name type=text Placeholder="Group Name"/>
                <button type="submit" class="btn btn-success btn-md">Create Group</button>
            </form>
            </div>
        </div>
        <!---------------------------------->

        <!-- Basic Data Tables -->
        <!--===================================================-->
        <div class="panel">
            <div class="panel-heading">
                <h3 class="panel-title">List of Groups in <strong><?php echo e(\Auth::user()->branchname); ?></strong> (<i><?php echo e(\Auth::user()->branchcode); ?></i>)</h3>
            </div>
            <div class="panel-body" style="overflow:scroll">
                <table id="demo-dt-basic" class="table table-striped table-bordered datatable" cellspacing="0" width="100%" >
                    <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Group Name</th>
                            <th>Members</th>
                            <th>Date Created</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count=1;?>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($count); ?></th>
                            <td><strong><?php echo e(strtoupper($group->name)); ?></strong></td>
                            <td><?php echo e($group->getNumberOfMembers()); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse(substr($group->created_at, 0, 10))->format('l, jS \\of F Y')); ?></td>
                            <td>
                                <a class="btn btn-success btn-sm" href="<?php echo e(route('group.view', $group->id)); ?>">View Group</a>
                                <a class="btn btn-danger btn-sm" href="<?php echo e(route('group.delete', $group->id)); ?>">Delete Group</a>
                            </td>
                        </tr>
                        <?php $count++;?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
        </div>
        <!--===================================================-->
        <!-- End Striped Table -->


    </div>
    <!--===================================================-->
    <!--End page content-->

</div>
<!--===================================================-->
<!--END CONTENT CONTAINER-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>