<?php $__env->startSection('title'); ?> Head Office <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--CONTENT CONTAINER-->
<!--===================================================-->
<div id="content-container">
    <div id="page-head">

        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Head office</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->


        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
            <li>
                <a href="forms-general.html#">
                    <i class="demo-pli-home"></i>
                </a>
            </li>
            <li>
                <a href="forms-general.html#">Admin Tools</a>
            </li>
            <li class="active">Head office</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->

    </div>


    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="table table-striped table-bordered"  >
                <?php if(session('status')): ?>

                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="alert alert-danger"><?php echo e($error); ?></div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>
            </div>
            <div class="">
                <div class="panel" style="overflow:scroll; background-color: #e8ddd3;">
                    <div class="panel-heading">
                        <h3 class="panel-title">Edit Options</h3>
                    </div>

                    <!--Block Styled Form -->
                    <!--===================================================-->
					<div class="panel-body">
					<table class="table table-hover" id="dev-table">
						<thead>
							<tr>
								<th>#</th>
								<th>HOSNAME</th>
								<th>HOLNAME</th>
								<th>HOADDRESS</th>
								<th>HOADDRESS2</th>
								<th>HOCITY</th>
								<th>HOSTATE</th>
								<th>HOPOSTAL_CODE</th>
								<th>HOCOUNTRY</th>
								<th>HOPHONE1</th>
								<th>HOPHONE2</th>
								<th>HOPHONE3</th>
								<th>HOPHONE4</th>
								<th>HOEMAIL</th>
								<th>HOLOGO</th>
							</tr>
						</thead>
						<tbody>
                        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    <tr id="def">
								<td><?php echo e($option->HOID); ?></td>
                <td id="<?php echo e($option->HOSNAME); ?>1" class=""><?php echo e($option->HOSNAME); ?></td>
								<td id="<?php echo e($option->HOLNAME); ?>2" class=""><?php echo e($option->HOLNAME); ?></td>
								<td id="<?php echo e($option->HOADDRESS); ?>3" class=""><?php echo e($option->HOADDRESS); ?></td>
								<td id="<?php echo e($option->HOADDRESS2); ?>4" class=""><?php echo e($option->HOADDRESS2); ?></td>
								<td id="<?php echo e($option->HOCITY); ?>5" class=""><?php echo e($option->HOCITY); ?></td>
								<td id="<?php echo e($option->HOSTATE); ?>6" class=""><?php echo e($option->HOSTATE); ?></td>
								<td id="<?php echo e($option->HOPOSTAL_CODE); ?>7" class=""><?php echo e($option->HOPOSTAL_CODE); ?></td>
								<td id="<?php echo e($option->HOCOUNTRY); ?>14" class=""><?php echo e($option->HOCOUNTRY); ?></td>
								<td id="<?php echo e($option->HOPHONE1); ?>8" class=""><?php echo e($option->HOPHONE1); ?></td>
								<td id="<?php echo e($option->HOPHONE2); ?>9" class=""><?php echo e($option->HOPHONE2); ?></td>
								<td id="<?php echo e($option->HOPHONE3); ?>10" class=""><?php echo e($option->HOPHONE3); ?></td>
								<td id="<?php echo e($option->HOPHONE4); ?>11" class=""><?php echo e($option->HOPHONE4); ?></td>
								<td id="<?php echo e($option->HOEMAIL); ?>12" class=""><?php echo e($option->HOEMAIL); ?></td>
								<td id="13" class=""><img class="img-responsive" src="data:image/jpeg;base64, <?php echo e(base64_encode($option->HOLOGO) . ''); ?>"></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<form class="table" id="update_ho" enctype="multipart/form-data" method="post" action="<?php echo e(route('branch.ho.up')); ?>">
					    <tr id="mod" style="display:none">
                            <td>#</td>
					        <td><input name="sname" type="text" class="form-control" value="<?php echo e($option->HOSNAME); ?>"></td>
					        <td><input name="lname" type="text" class="form-control" value="<?php echo e($option->HOLNAME); ?>"></td>
					        <td><input name="addr1" type="text" class="form-control" value="<?php echo e($option->HOADDRESS); ?>"></td>
					        <td><input name="addr2" type="text" class="form-control" value="<?php echo e($option->HOADDRESS2); ?>"></td>
					        <td><input name="city" type="text" class="form-control" value="<?php echo e($option->HOCITY); ?>"></td>
					        <td><input name="state" type="text" class="form-control" value="<?php echo e($option->HOSTATE); ?>"></td>
					        <td><input name="postal" type="text" class="form-control" value="<?php echo e($option->HOPOSTAL_CODE); ?>"></td>
					        <td><input name="country" type="text" class="form-control" value="<?php echo e($option->HOCOUNTRY); ?>"></td>
					        <td><input name="phone1" type="number" class="form-control" value="<?php echo e($option->HOPHONE1); ?>"></td>
					        <td><input name="phone2" type="number" class="form-control" value="<?php echo e($option->HOPHONE2); ?>"></td>
					        <td><input name="phone3" type="number" class="form-control" value="<?php echo e($option->HOPHONE3); ?>"></td>
					        <td><input name="phone4" type="number" class="form-control" value="<?php echo e($option->HOPHONE4); ?>"></td>
					        <td><input name="email" type="email" class="form-control" value="<?php echo e($option->HOEMAIL); ?>"></td>
					        <td><input name="img" type="file" accept=".jpg,.gif,.png"  class="form-control" value=""></td>
					    </tr>
              <input name="id" type="hidden" value="<?php echo e($option->HOID); ?>">
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						</tbody>
					</table>
                    <div class="row">
                       <div class="col-md-3">
                            <button id="edit-ho" type='button' class="btn btn-danger" onclick="saveHo(this);">Edit</button>
                            <button style="display:none" id="save-ho" type='submit' name="update" class="btn btn-danger" onclick="">Save</button>
                            <button style="display:none" id="cancel-ho" type='button' class="btn btn-warning" onclick="">Cancel</button>
                        </div>
					</form>
                    </div>
			    </div>
                    <!--===================================================-->
                    <!--End Block Styled Form -->

                </div>
            </div>


        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->

</div>

<!--===================================================-->
<!--END CONTENT CONTAINER-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>