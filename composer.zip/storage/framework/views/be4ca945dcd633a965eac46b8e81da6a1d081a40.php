<?php $__env->startSection('title'); ?> All Branches Collection Report <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--CONTENT CONTAINER-->
<!--===================================================-->
<div id="content-container">
    <div id="page-head">

        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Collections Report</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->

        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
            <li>
                <a href="forms-general.html#">
                    <i class="demo-pli-home"></i>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('attendance')); ?>">Reports</a>
            </li>
            <li class="active">Collections</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->

    </div>


    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="col-md-6 col-md-offset-3"  >
                <?php if(session('status')): ?>

                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="alert alert-danger"><?php echo e($error); ?></div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>
            </div>
            <?php $currency = \Auth::user()->getCurrencySymbol()->currency_symbol; ?>
            <div class="col-md-8 col-md-offset-2" style="margin-bottom:20px">
              <div class="panel" style="background-color: #e8ddd3;">
                  <div class="panel-heading">
                      <h3 class="panel-title"><strong>All Branches Collections Report</strong></h3>
                  </div>
                <div class="panel-body">
                  <table class="table text-center">
                    <thead class="bg-warning text-center">
                      <tr><th colspan="3" class="bg-light text-center">Total Collections </th></tr>
                      <tr>
                        <th>

                        </th>
                        <th class="text-center">
                          Till Date
                        </th>
                        <th class="text-center">
                          Today's
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th>
                          Total Amount Collected
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->total_collections)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->todays_collections)); ?></span>
                        </td>
                      </tr>
                    </tbody>
                  </table>

                </div>
              </div>
            </div>

            <div class="col-md-8 col-md-offset-2" style="margin-bottom:20px">
              <div class="panel" style="background-color: #e8ddd3;">
                  <div class="panel-heading">
                      <h3 class="panel-title"><strong>Total Collection By Type</strong></h3>
                  </div>
                <div class="panel-body">
                  <table class="table text-center">
                    <thead class="bg-warning text-center">
                      <tr>
                        <th class="text-center">
                          Collections Type
                        </th>
                        <th class="text-center">
                          Till Date
                        </th>
                        <th class="text-center">
                          Today's
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th>
                          Special Offering
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->so)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->sot)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          Seed Offering
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->sdo)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->sdot)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          Offering
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->o)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->oth)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          Donation
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->d)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->dt)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          Tithe
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->t)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->tt)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          First Fruit
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->ff)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->fft)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          Covenant Seed
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->cs)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->cst)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          Love Seed
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->ls)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->lst)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          Sacrifice
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->s)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->st)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          Thanksgiving
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->tg)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->tgt)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          Thanksgiving Seed
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->tgs)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->tgst)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          Other
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->oth)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->otht)); ?></span>
                        </td>
                      </tr>
                    </tbody>
                    <tfoot class="bg-success">
                      <tr>
                        <th>
                          Total
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->total_collections)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($reports[0]->todays_collectionst)); ?></span>
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>

            <div class="col-md-8 col-md-offset-2" style="margin-bottom:20px">
              <div class="panel" style="background-color: #e8ddd3;">
                  <div class="panel-heading">
                      <h3 class="panel-title"><strong>Total Branches Collections</strong></h3>
                  </div>
                <div class="panel-body">
                  <table class="table text-center">
                    <thead class="bg-warning text-center">
                      <tr>
                        <th class="text-center">
                          Branch Name
                        </th>
                        <th class="text-center">
                          Till Date
                        </th>
                        <th class="text-center">
                          Today's
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $total = 0; $totalt = 0; ?>
                      <?php $__currentLoopData = $ad_rep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $total += ($ar->ctotal); $totalt += ($ar->ctotalt); ?>
                      <tr>
                        <th>
                          <?php echo e($ar->name); ?>

                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($ar->ctotal)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($ar->ctotalt)); ?></span>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="bg-success">
                      <tr>
                        <th>
                          Total
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($total)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e($currency); ?> <?php echo e(number_format($totalt)); ?></span>
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>

            <?php
            $years = [];
            $i = 9;
            while ($i >= 0) {

            $years[$i] = date('Y', strtotime("-$i year")); //1 week ago
            $i--;
            }
            ?>

            <div class="col-md-12 col-md-offset-0" style="margin-bottom:20px">
              <div class="panel" style="background-color: #e8ddd3;">
                  <div class="panel-heading">
                      <h3 class="panel-title"><strong>Last 10 <i>Years</i> Collection</strong> Report</h3>
                  </div>
                <div class="panel-body">
                  <table id="demo-dt-basic" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
                    <thead class="bg-dark text-white">
                      <tr>
                        <th>Type</th>
                        <?php  $totalss = [];
                        $totals = []; $type = ['tithe', 'offering', 'other'];
                        foreach ($type as $key => $value) {
                          $totalss[$value] = 0;
                        }
                        foreach ($years as $key => $value) { $totals[$value] = 0; ?>
                        <th><?php echo e($value); ?></th>
                        <?php } ?>
                        <th>Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th><?php echo e(ucwords($t)); ?></th>
                      <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $found = false; ?>
                        <?php $__currentLoopData = $c_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($v->year == $value){
                          $found = true;
                          if($v->$t){
                            $totals[$value] += ($v->$t) ? $v->$t : 0;
                            $totalss[$t] += ($v->$t) ? $v->$t : 0;
                            echo '<td>'.$currency.number_format($v->$t).'</td>';}else{echo $currency.'<td>0</td>';
                            }
                          } ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$found): ?>
                        <td>No Record</td>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($currency.''.number_format($totalss[$t])); ?></th>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--th scope="row">3</th-->
                    </tbody>
                    <tfoot class="bg-success text-white">
                      <tr>
                        <th>Total</th>
                        <?php foreach ($totals as $key => $value) { ?>
                        <th><?php echo e($currency.number_format($value)); ?></th>
                        <?php } ?>
                        <th><?php $q = 0; foreach($totalss as $plus => $v){$q += $v;} echo $currency.number_format($q);?></th>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>


        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<!--===================================================-->
<!--END CONTENT CONTAINER-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>