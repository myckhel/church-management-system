<?php $__env->startSection('title'); ?> <?php echo e(\Auth::user()->branchname); ?><?php echo e(\Auth::user()->branchcode); ?>: Attendance Report <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php

// extract addedVariables value to variable
if (isset($addedVariables)) extract($addedVariables);

?>
<!--CONTENT CONTAINER-->
<!--===================================================-->
<style>
li {
    display: inline;
}
/* Dropdown Button */
.dropbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
    position: relative;
    display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd;}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
<div id="content-container">
    <div id="page-head">

        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Attendance</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->


        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
            <li>
                <a href="forms-general.html#">
                    <i class="demo-pli-home"></i>
                </a>
            </li>
            <li>
                <a href="forms-general.html#">Attendance</a>
            </li>
            <li class="active">All</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->

    </div>


    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="col-md-6 col-md-offset-3"  >
                <?php if(session('status')): ?>

                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="alert alert-danger"><?php echo e($error); ?></div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>
            </div>
            <div class="col-sm-6 col-sm-offset-3" style="margin-bottom:<?php
            echo (isset($formatted_date)) ? '30' : '60';
            ?>px">
                <div class="panel">
                    <div class="panel-heading">
                        <h3 class="panel-title">View Attendance for <strong><?php echo e(\Auth::user()->branchname); ?> <i><?php echo e(\Auth::user()->branchcode); ?></i></strong></h3>

                    </div>

                    <!--Block Styled Form -->
                    <!--===================================================-->
                    <form method="POST" action="<?php echo e(route('attendance.view')); ?>">
                        <?php echo csrf_field(); ?>
                        <input name="branch_id" value="3" type="text" hidden="hidden"/>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label class="control-label">Choose Specific Date</label>
                                        <input type="date" value="<?php if (isset($request_date)) echo $request_date;?>" name="date" class="form-control">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer text-right">
                            <button class="btn btn-success" type="submit">VIEW ATTENDANCE</button>
                        </div>
                    </form>
                    <!--===================================================-->
                    <!--End Block Styled Form -->

                </div>

            </div>
            <?php if (!isset($addedVariables)){ ?>
            <div class="col-md-offset-1 col-md-10" style="margin-bottom:50px">
                <div class="panel">
                <div class="panel-body text-center clearfix" style="overflow:scroll">
                  <table id="demo-dt-basic" class="table table-striped table-bordered datatable" cellspacing="0" width="100%" >
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th class="min-tablet">Service type</th>
                        <th class="min-tablet">Men</th>
                        <th class="min-tablet">Women</th>
                        <th class="min-tablet">Children</th>
                        <th class="min-tablet">Total</th>
                        <th class="min-tablet">Date</th>
                        <th class="min-tablet">Day</th>
                        <th class="min-tablet">Month</th>
                        <th class="min-tablet">Year</th>
                        <th class="min-desktop">Action</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $count=1;?>
                  <h1>Branch Attendance History<h1>
                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $date = $list->attendance_date;
                      $d = date("F,Y,D", strtotime($date));
                      $p = explode(',',$d);
                    ?>
                    <tr>
                        <td><strong><?php echo e($count); ?></strong></td>
                        <td><?php echo e($list->service_type); ?></td>
                        <td><?php echo e($list->male); ?></td>
                        <td><?php echo e($list->female); ?></td>
                        <td><?php echo e($list->children); ?></td>
                        <td><?php echo e($list->male + $list->female + $list->children); ?></td>
                        <td><?php echo e($list->attendance_date); ?></td>
                        <td><?php echo e($p[2]); ?></td>
                        <td><?php echo e($p[0]); ?></td>
                        <td><?php echo e($p[1]); ?></td>
                        <td><button id="<?php echo e($list->attendance_date); ?>" type="submit" class="btn btn-primary" onclick="view(this);">View</button></td>
                    </tr>
                    <?php $count++;?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
          </div>
        </div>

      <?php }else{ ?>
            <div class="col-md-offset-3 col-md-6" style="margin-bottom:350px">
                <div class="panel">
                    <div class="panel-body text-center clearfix">
                        <div class="col-sm-4 pad-top">
                            <div class="text-lg">
                                <p class="text-5x text-thin text-main"><?php echo e($attendance->getTotal()); ?></p>
                            </div>
                            <p class="text-sm text-bold text-uppercase">Total Attendance</p>
                        </div>
                        <div class="col-sm-8">
                            <!--<button class="btn btn-pink mar-ver">View Details</button>
                            <p class="text-xs">Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>-->
                            <ul class="list-unstyled text-center bord-to pad-top mar-no row">
                                <li class="col-xs-4">
                                    <span class="text-lg text-semibold text-main"><?php echo e($attendance->male); ?></span>
                                    <p class="text-sm text-muted mar-no">Men</p>
                                </li>
                                <li class="col-xs-4">
                                    <span class="text-lg text-semibold text-main"><?php echo e($attendance->female); ?></span>
                                    <p class="text-sm text-muted mar-no">Women</p>
                                </li>
                                <li class="col-xs-4">
                                    <span class="text-lg text-semibold text-main"><?php echo e($attendance->children); ?></span>
                                    <p class="text-sm text-muted mar-no">Children</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <a style="float:right;" href="<?php echo e(route('attendance.view.form')); ?>" class="btn btn-success">View Attendance History</a>
            </div>
            <?php } ?>

            <!-- MEMBERS ATTENDANCE -->
            <?php if (!isset($addedVariables)){ ?>
            <div class="col-md-offset-1 col-md-10" style="margin-bottom:50px">
                <div class="panel">
                <div class="panel-body text-center clearfix" style="overflow:scroll">
            <table id="demo-dt-basic" class="table table-striped table-bordered datatable" cellspacing="0" width="100%" >
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th class="min-tablet">Title</th>
                        <th class="min-tablet">First Name</th>
                        <th class="min-tablet">Last Name</th>
                        <th class="min-tablet">Attendance</th>
                        <th class="min-tablet">Service type</th>
                        <th class="min-tablet">Date</th>
                        <!--th class="min-desktop">Action</th-->
                    </tr>
                </thead>
                <tbody>
                  <?php $count=1;?>
                  <h1>Members Attendance History<h1>
                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $li): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $date = $li->attendance_date;
                      $d = date("F,Y,D", strtotime($date));
                      $p = explode(',',$d);
                    ?>
                    <tr>
                        <td><strong><?php echo e($count); ?></strong></td>
                        <td><?php echo e($li->title); ?></td>
                        <td><?php echo e($li->firstname); ?></td>
                        <td><?php echo e($li->lastname); ?></td>
                        <td><?php echo e($li->attendance); ?></td>
                        <td><?php echo e($li->service_type); ?></td>
                        <td ><?php echo e($li->attendance_date); ?></td>
                        <!--td><button id="<?php echo e($li->attendance_date); ?>" type="submit" class="btn btn-primary" onclick="view(this);">View</button></td-->
                    </tr>
                    <?php $count++;?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
          </div>
        </div>
      <?php }?>
        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->

</div>
<!--===================================================-->
<!--END CONTENT CONTAINER-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>