<?php $__env->startSection('title'); ?> Attendance Report <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--CONTENT CONTAINER-->
<!--===================================================-->
<div id="content-container">
    <div id="page-head">

        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Attendance Report</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->

        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
            <li>
                <a href="forms-general.html#">
                    <i class="demo-pli-home"></i>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('attendance')); ?>">Reports</a>
            </li>
            <li class="active">Attendance</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->

    </div>


    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">
            <div class="col-md-6 col-md-offset-3"  >
                <?php if(session('status')): ?>

                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="alert alert-danger"><?php echo e($error); ?></div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>
            </div>
            <?php $name = \Auth::user()->getName() . ' ' .\Auth::user()->branchcode; ?>
            <div class="col-md-8 col-md-offset-2" style="margin-bottom:20px">
              <div class="panel" style="background-color: #e8ddd3;">
                  <div class="panel-heading">
                      <h3 class="panel-title"><strong><?php echo e($name); ?> Attendance</strong> Report</h3>
                  </div>
                <div class="panel-body">
                  <table class="table text-center">
                    <thead class="bg-warning text-center">
                      <tr><th colspan="3" class="bg-light text-center"><?php echo e($name); ?> Attendance Report </th></tr>
                      <tr>
                        <th>

                        </th>
                        <th class="text-center">
                          Till Date
                        </th>
                        <th class="text-center">
                          Today's
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th>
                          Total
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(isset($reports[0]->total_attendance) ? $reports[0]->total_attendance : 0); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(isset($reports[0]->todays_attendance) ? $reports[0]->todays_attendance : 0); ?></span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div class="col-md-8 col-md-offset-2" style="margin-bottom:20px">
              <div class="panel" style="background-color: #e8ddd3;">
                  <div class="panel-heading">
                      <h3 class="panel-title"><strong>Total Attendance By Type</strong></h3>
                  </div>
                <div class="panel-body">
                  <table class="table text-center">
                    <thead class="bg-warning text-center">
                      <tr>
                        <th class="text-center">
                          Type
                        </th>
                        <th class="text-center">
                          Till Date
                        </th>
                        <th class="text-center">
                          Today's
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th>
                          Male
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(number_format($reports[0]->male)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(number_format($reports[0]->malet)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          Female
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(number_format($reports[0]->female)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(number_format($reports[0]->femalet)); ?></span>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          Children
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(number_format($reports[0]->children)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(number_format($reports[0]->childrent)); ?></span>
                        </td>
                      </tr>
                    </tbody>
                    <tfoot class="bg-success">
                      <tr>
                        <th>
                          Total
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(number_format($reports[0]->total)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(number_format($reports[0]->totalt)); ?></span>
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>

            <?php
            $years = [];
            $i = 9;
            while ($i >= 0) {

            $years[$i] = date('Y', strtotime("-$i year")); //1 week ago
            $i--;
            }
            ?>

            <div class="col-md-12 col-md-offset-0" style="margin-bottom:20px">
              <div class="panel" style="background-color: #e8ddd3;">
                  <div class="panel-heading">
                      <h3 class="panel-title"><strong>Last 10 <i>Years</i> Attendance</strong> Report</h3>
                  </div>
                <div class="panel-body">
                  <table class="table" id="demo-dt-basic" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
                    <thead class="bg-dark text-white">
                      <tr>
                        <th>Type</th>
                        <?php $totals = []; $type = ['male', 'female', 'children']; foreach ($years as $key => $value) { $totals[$value] = 0; ?>
                        <th><?php echo e($value); ?></th>
                        <?php } ?>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th><?php echo e(ucwords($t)); ?></th>
                      <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $found = false; ?>
                        <?php $__currentLoopData = $a_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($v->year == $value){
                          $found = true; if($v->$t){
                            $totals[$value] += ($v->$t) ? $v->$t : 0;
                            echo '<td>'.$v->$t.'</td>';}else{echo '<td>0</td>';
                            }
                        } ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$found): ?>
                        <td>No Record</td>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--th scope="row">3</th-->
                    </tbody>
                    <tfoot class="bg-success text-white">
                      <tr>
                        <th>Total</th>
                        <?php foreach ($totals as $key => $value) { ?>
                        <th><?php echo e($value); ?></th>
                        <?php } ?>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>

            <div class="col-md-8 col-md-offset-2" style="margin-bottom:20px">
              <div class="panel" style="background-color: #e8ddd3;">
                  <div class="panel-heading">
                      <h3 class="panel-title"><strong>Total attendance <i>By</i> Members Till Date</strong></h3>
                  </div>
                <div class="panel-body">
                  <table class="table text-center">
                    <thead class="bg-warning text-center">
                      <tr><th colspan="3" class="bg-light text-center">Member</th></tr>
                      <tr>
                        <th class="text-center">
                          Name
                        </th>
                        <th class="text-center">
                          Till Date
                        </th>
                        <th class="text-center">
                          Today's
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $total = 0; $totalt = 0;?>
                      <?php $__currentLoopData = $m_r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $total += $mc->total; $totalt += $mc->totalt; ?>
                      <tr>
                        <th>
                          <?php echo e($mc->fname); ?> <?php echo e($mc->lname); ?>

                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(number_format($mc->total)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(number_format($mc->totalt)); ?></span>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="bg-success">
                      <tr>
                        <th>
                          Total
                        </th>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(number_format($total)); ?></span>
                        </td>
                        <td>
                          <span class="badge badge-primary badge-pill"><?php echo e(number_format($totalt)); ?></span>
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>

        </div>
    </div>
    <!--===================================================-->
    <!--End page content-->
</div>
<!--===================================================-->
<!--END CONTENT CONTAINER-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>