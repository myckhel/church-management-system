<?php $__env->startSection('title'); ?> Ticketing - Report <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<!--CONTENT CONTAINER-->
<!--===================================================-->
<div id="content-container">
  <div id="page-head">

    <!--Page Title-->
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <div id="page-title">
      <h1 class="page-header text-overflow">Create Ticket</h1>
    </div>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <!--End page title-->


    <!--Breadcrumb-->
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <ol class="breadcrumb">
      <li>
        <a href="forms-general.html#">
          <i class="demo-pli-home"></i>
        </a>
      </li>
      <li>
         <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            </li>
            <li class="active">Ticketing</li>
    </ol>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <!--End breadcrumb-->

  </div>


  <!--Page content-->
  <!--===================================================-->
  <div id="page-content">
    <div class="row">
      <div class="col-lg-8 col-lg-offset-2">
        <div class="panel" style="background-color: #e8ddd3;">
          <div class="panel-heading">
            <h1 class="text-center" style="padding-top:5px">Create Ticket</h2>
          </div>
          <div class="col-lg-10 col-lg-offset-2">
          <?php if(session('status')): ?>

                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                   <!--  <?php if(count($errors) > 0): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="alert alert-danger"><?php echo e($error); ?></div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?> -->


          </div>
          <div class="row panel-body">
            <div class=""  style="border:1pt solid #090c5e; border-radius:25px;">
              <!-- BASIC FORM ELEMENTS -->
              <!--===================================================-->
                  <form id="send-ticket-form" role="form"  method="POST" action="<?php echo e(route('sendTicket')); ?>">
                                    <?php   $randid= mt_rand(13, rand(100, 99999990));?>
                                         <?php echo csrf_field(); ?>  <div class="panel-body">
                                        <div class="row">
                                               <input type="hidden"  id="TicketID" class="form-control" name="TicketID" value="<?php echo e($randid); ?>">
                                            <div class="col-md-4 mar-btm">
                                                 <label class=" control-label"  for="inputEmail">Error Code</label>
                                                     <input type="text"  id="error_code" class="form-control<?php echo e($errors->has('error_code') ? ' is-invalid' : ''); ?>" name="error_code" value="<?php echo e(old('error_code')); ?>">
                                                      <br>
                                <?php if($errors->has('error_code')): ?>
                                    <span class="alert alert-danger">
                                        <strong><?php echo e($errors->first('error_code')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                            </div>
                                        <div class="col-md-4 mar-btm">
                                                 <label class=" control-label"  for="inputEmail">Error Name</label>
                                                     <input type="text"  id="error_name" class="form-control<?php echo e($errors->has('error_name') ? ' is-invalid' : ''); ?>" name="error_name" value="<?php echo e(old('error_name')); ?>">
                                            <br>
                                <?php if($errors->has('error_name')): ?>
                                    <span class="alert alert-danger">
                                        <strong><?php echo e($errors->first('error_name')); ?></strong>
                                    </span>
                                <?php endif; ?> </div>
                                              <div class="col-md-4 mar-btm">
                                           <label class="control-label"  for="inputEmail">Severity</label>
                                         <select class="form-control" name="severity" id="severity">
                                           <option >select Option</option>
                          <option value="Show Stopper">Show Stopper</option>
                          <option value="One Offs">One Offs</option>
                          <option value="Severe">Severe</option>
                          <option value="Can Manage">Can Manage</option>
                      </select>
                                             <br>
                                <?php if($errors->has('severity')): ?>
                                    <span class="alert alert-danger">
                                        <strong><?php echo e($errors->first('severity')); ?></strong>
                                    </span>
                                <?php endif; ?>
                    </div>
                                         </div>
                                         <div class="row">

                           <div class="col-md-4 mar-btm">
                                             <label class="control-label"  for="inputEmail">Service Level</label>
                                         <select class="form-control" name="servicelevel" id="servicelevel">
                                           <option >select Option</option>
                          <option class="bg bg-success" value="Level 1"><p >Green</p></option>
                          <option class="bg-yellow" value="Level 2"><p >Yellow</p></option>
                          <option class="bg-danger" value="Level 3"><p >Red</p></option>
                      </select>
                                             <br>
                                <?php if($errors->has('servicelevel')): ?>
                                    <span class="alert alert-danger">
                                        <strong><?php echo e($errors->first('servicelevel')); ?></strong>
                                    </span>
                                <?php endif; ?>
                    </div>
                      <div class="col-md-4 mar-btm">
                                                         <label class=" control-label" for="inputSubject">Ticket Date</label>
                                             <input style="border:1px solid rgba(0,0,0,0.07);height: 33px;
                                  font-size: 13px;
                                  border-radius: 3px;display: block;
                                  width: 100%;
                                   color: #555;
                                  background-color: #fff;outline:none; margin-top:2px;padding:2px 10px" type="text" placeholder="Ticket  Date" name="date" class="datepicker"/>

                    <br>
                                <?php if($errors->has('date')): ?>
                                    <span class="alert alert-danger">
                                        <strong><?php echo e($errors->first('date')); ?></strong>
                                    </span>
                                <?php endif; ?>

                                        </div>

                                            <div class="col-md-4 mar-btm">
                                                         <label class=" control-label" for="inputSubject">Ticket Time</label>
                                  <div class="input-group clockpicker col-md-9">
                                <input type="text" class="form-control" value="09:00" name="time">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-time"></span>
                                </span>
                            </div> <?php if($errors->has('time')): ?>
                                    <span class="alert alert-danger">
                                        <strong><?php echo e($errors->first('time')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                            </div>


                  </div>
                        <div class="row">

                                            <div class="col-md-4 mar-btm">
                                                 <label class=" control-label"  for="inputEmail">Full Name</label>
                                                     <input type="text"  id="full_name" class="form-control<?php echo e($errors->has('full_name') ? ' is-invalid' : ''); ?>" name="full_name" value="<?php echo e(old('full_name')); ?>">
                                        <?php if($errors->has('full_name')): ?>
                                    <span class="alert alert-danger">
                                        <strong><?php echo e($errors->first('full_name')); ?></strong>
                                    </span>
                                <?php endif; ?>     </div>

                                       <div class="col-md-4 mar-btm">
                                                 <label class="col-md-3 control-label"  for="inputEmail">Email</label>
                                                     <input type="email"  id="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>">
                                          <?php if($errors->has('email')): ?>
                                    <span class="alert alert-danger">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>   </div>
                                            <div class="col-md-4 mar-btm">
                                                 <label class=" control-label"  for="inputEmail">Phone Number</label>
                                                     <input type="tel"  id="phone_number" class="form-control<?php echo e($errors->has('phone_number') ? ' is-invalid' : ''); ?>" name="phone_number" value="<?php echo e(old('phone_number')); ?>">
                                           <?php if($errors->has('phone_number')): ?>
                                    <span class="alert alert-danger">
                                        <strong><?php echo e($errors->first('phone_number')); ?></strong>
                                    </span>
                                <?php endif; ?>  </div>
                                         </div>

                                           <div class="row">


                                        <textarea placeholder="Error Description" name="message" rows="10" class="form-control"></textarea>
                                   <?php if($errors->has('message')): ?>
                                    <span class="alert alert-danger">
                                        <strong><?php echo e($errors->first('message')); ?></strong>
                                    </span>
                                <?php endif; ?>  </div>
                                    <div class="panel-footer text-right">
                                       <button id="mail-send-btn" type="submit" class="btn btn-primary">
                                                <i class="demo-psi-mail-send icon-lg icon-fw"></i> Create Ticket
                                            </button>
                                    </div>
                                </form>
            </div>
          </div>
          <!--===================================================-->
          <!-- END BASIC FORM ELEMENTS -->




        </div>
      </div>
    </div>


  </div>
  <!--===================================================-->
  <!--End page content-->

</div>
<!--===================================================-->
<!--END CONTENT CONTAINER-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>