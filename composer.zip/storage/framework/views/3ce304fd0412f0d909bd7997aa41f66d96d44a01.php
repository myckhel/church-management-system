<?php $__env->startSection('title'); ?> View Collection <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--CONTENT CONTAINER-->
<!--===================================================-->
<div id="content-container">
    <div id="page-head">

        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">View Collection</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->


        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
            <li>
                <a href="forms-general.html#">
                    <i class="demo-pli-home"></i>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('collection.report')); ?>">Collection</a>
            </li>
            <li class="active">Report</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->

    </div>


    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">
        <div class="row">

            <!--div class="col-sm-12 col-md-10 col-md-offset-1">
                <div class="panel">
                    <div class="panel-body demo-nifty-btn">

                        <!--Rounded Buttons-->
                        <!--===================================================-->
                        <!--a style="min-width:100px !important" class="btn btn-primary btn-rounded">Offering</a>
                        <a style="min-width:100px !important" class="btn btn-primary btn-rounded">Donation</a>
                        <a style="min-width:100px !important" class="btn btn-primary btn-rounded">Tithe</a-->
                        <!--a href="<?php echo e(route('collection.report')); ?>" style="min-width:100px !important"  class="btn btn-success btn-rounded">Reports</a>
                        <!--===================================================-->

                    <!--/div>
                </div>
            </div-->


        <!--div class="col-md-8 col-md-offset-2">

          <!-- Bar Chart -->
          <!---------------------------------->
          <!--div class="panel">
              <div class="panel-heading">
                  <h3 class="panel-title">Total Monthly Collection</h3>
              </div>
              <div class="panel-body">
                  <div id="demo-flot-bar" style="height: 250px"></div>
              </div>
          </div-->
          <!---------------------------------->


        <!--/div-->

            <div class="col-md-12 col-md-offset-0">
        <!-- Basic Data Tables -->
        <!--===================================================-->
        <div class="panel">
            <div class="panel-heading">
            </div>
            <div class="panel-body">
                <table id="demo-dt-basic" class="table table-striped table-bordered datatable" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                          <th>S/N</th>
                          <th>Collection Type</th>
                          <th>Special Offering</th>
                          <th>Seed Offering</th>
                          <th>Tithe</th>
                          <th class="min-tablet">Offering</th>
                          <th class="min-tablet">Donation</th>
                          <th class="min-desktop">First Fruit</th>
                          <th class="min-desktop">Covenant Seed</th>
                          <th class="min-desktop">Love Seed</th>
                          <th class="min-desktop">Sacrifice</th>
                          <th class="min-desktop">Thanksgiving</th>
                          <th class="min-desktop">Thanksgiving Seed</th>
                          <th class="min-desktop">Other</th>
                          <th class="min-desktop">Total</th>
                          <!--th class="min-desktop">Date Saved</th-->
                          <th class="min-desktop">Date</th>
                          <th class="min-desktop">Month</th>
                          <th class="min-desktop">Year</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php $count=1;?>
                      <h1>Collection History<h1>
                        <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          $date = $list->date_collected;
                          $d = date("F,Y,D", strtotime($date));
                          $p = explode(',',$d);
                        ?>
                        <tr>
                          <td><?php echo e($count); ?></td>
                          <td><?php echo e($list->type); ?></td>
                          <td><?php echo e($list->special_offering); ?></td>
                          <td><?php echo e($list->seed_offering); ?></td>
                          <td><?php echo e($list->tithe); ?></td>
                          <td><?php echo e($list->offering); ?></td>
                          <td><?php echo e($list->donation); ?></td>
                          <td><?php echo e($list->first_fruit); ?></td>
                          <td><?php echo e($list->covenant_seed); ?></td>
                          <td><?php echo e($list->love_seed); ?></td>
                          <td><?php echo e($list->sacrifice); ?></td>
                          <td><?php echo e($list->thanksgiving); ?></td>
                          <td><?php echo e($list->thanksgiving_seed); ?></td>
                          <td><?php echo e($list->other); ?></td>
                          <td><?php echo e($list->amount); ?></td>
                          <!--td><?php echo e($list->date_collected); ?></td-->
                          <td><?php echo e($date); ?></td>
                          <td><?php echo e($p[0]); ?></td>
                          <td><?php echo e($p[1]); ?></td>
                        </tr>
                        <?php $count++;?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!--===================================================-->
        <!-- End Striped Table -->
        </div>

        <div class="col-md-12 col-md-offset-0" style="margin-bottom:50px">
            <div class="panel">
            <div class="panel-heading">
                    <h3 class="panel-title"><strong> <i></i> </strong>Members Collection History</h3>
            </div>
            <div class="panel-body text-center clearfix" style="overflow:scroll">
        <table id="demo-dt-basic" class="table table-striped table-bordered datatable" cellspacing="0" width="100%" >
            <thead>
                <tr>
                  <th>S/N</th>
                  <th>Name</th>
                  <th>Collection Type</th>
                  <th>Special Offering</th>
                  <th>Seed Offering</th>
                  <th>Tithe</th>
                  <th class="min-tablet">Offering</th>
                  <th class="min-tablet">Donation</th>
                  <th class="min-desktop">First Fruit</th>
                  <th class="min-desktop">Covenant Seed</th>
                  <th class="min-desktop">Love Seed</th>
                  <th class="min-desktop">Sacrifice</th>
                  <th class="min-desktop">Thanksgiving</th>
                  <th class="min-desktop">Thanksgiving Seed</th>
                  <th class="min-desktop">Other</th>
                  <th class="min-desktop">Total</th>
                  <!--th class="min-desktop">Date Saved</th-->
                  <th class="min-desktop">Date</th>
                    <!--th class="min-desktop">Action</th-->
                </tr>
            </thead>
            <tbody>
              <?php $count=1;?>
              <h1>Members Collection History<h1>
                <?php $__currentLoopData = $collectionss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $li): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><strong><?php echo e($count); ?></strong></td>
                    <td><?php echo e($li->fname); ?> <?php echo e($li->lname); ?></td>
                    <td><?php echo e($li->service_type); ?></td>
                    <td><?php echo e($li->special_offering); ?></td>
                    <td><?php echo e($li->seed_offering); ?></td>
                    <td><?php echo e($li->tithe); ?></td>
                    <td><?php echo e($li->offering); ?></td>
                    <td><?php echo e($li->donation); ?></td>
                    <td><?php echo e($li->first_fruit); ?></td>
                    <td><?php echo e($li->covenant_seed); ?></td>
                    <td><?php echo e($li->love_seed); ?></td>
                    <td><?php echo e($li->sacrifice); ?></td>
                    <td><?php echo e($li->thanksgiving); ?></td>
                    <td><?php echo e($li->thanksgiving_seed); ?></td>
                    <td><?php echo e($li->other); ?></td>
                    <td><?php echo e(($li->special_offering + $li->seed_offering + $li->tithe + $li->offering + $li->donation + $li->first_fruit + $li->covenant_seed + $li->sacrifice + $li->thanksgiving + $li->thanksgiving_seed + $li->other)); ?></td>
                    <td><?php echo e($li->date_added); ?></td>
                    <!--td><button id="" type="submit" class="btn btn-primary" onclick="view(this);">View</button></td-->
                </tr>
                <?php $count++;?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
      </div>
      </div>
    </div>

        </div>

    </div>
    <!--===================================================-->
    <!--End page content-->

</div>
<!--===================================================-->
<!--END CONTENT CONTAINER-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>