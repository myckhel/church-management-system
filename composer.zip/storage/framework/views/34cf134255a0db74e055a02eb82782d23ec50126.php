Hello,
This is to notify you that you have been assigned to an event from
<?php echo ucwords(\Auth::user()->branchname.' '.\Auth::user()->branchcode); ?>.

<h2><b>Event Details:</b></h2>
<?php

?>
<p>title: <?php echo e($request->get('title')); ?></p>
<p>location: <?php echo e($request->get('location')); ?></p>
<p>time: <?php echo e($request->get('time')); ?></p>
<p>assign_to: <?php echo e($request->get('title')); ?></p>
<p>by_who: <?php echo e($request->get('by_who')); ?></p>
<p>details: <?php echo e($request->get('details')); ?></p>

<h3>Thank You</h3>
<?php echo e(Auth::user()->branchname); ?>

