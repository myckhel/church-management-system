<?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <p><?php echo e($row->HOFNAME); ?></p>
  <p><?php echo e($row->HOLNAME); ?></p>
  <p><?php echo e($row->HOCITY); ?></p>
  <p><?php echo e($row->HOCOUNTRY); ?></p>
  <p><?php echo e($row->HOADDRESS); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
