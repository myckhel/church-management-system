<?php $__env->startSection('title'); ?> All Branches <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--CONTENT CONTAINER-->
<!--===================================================-->
<div id="content-container">
    <div id="page-head">

        <!--Page Title-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <div id="page-title">
            <h1 class="page-header text-overflow">Branch</h1>
        </div>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End page title-->


        <!--Breadcrumb-->
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <ol class="breadcrumb">
          <li>
              <i class="fa fa-home"></i><a href="<?php echo e(route('dashboard')); ?>"> Dashboard</a>
          </li>
            <li class="active">All</li>
        </ol>
        <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
        <!--End breadcrumb-->

    </div>


    <!--Page content-->
    <!--===================================================-->
    <div id="page-content">



        <!-- Basic Data Tables -->
        <!--===================================================-->
        <div class="panel" style="overflow:scroll; background-color: #e8ddd3;">
            <div class="panel-heading">
                <h3 class="panel-title">List of All Branches</h3>
            </div>
            <div class="panel-body">
              <?php // print_r($users); ?>
                <table id="demo-dt-basic" class="table table-striped table-bordered datatable " cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <!--th>Country</th-->
                            <th>Branch Name</th>
                            <th>Address</th>
                            <th class="min-tablet">City</th>
                            <th class="min-tablet">State</th>
                            <th class="min-tablet">Country</th>
                            <th class="min-tablet">Branch Code</th>
                            <th class="min-desktop">Branch Role</th>
                            <th class="min-tablet">Currency</th>
                            <th class="min-desktop">Pastor in Charge</th>
                            <th class="min-desktop">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!--td><span class="flag-icon flag-icon-ng"></span> </td-->
                            <td><?php echo e($user->branchname); ?></td>
                            <td><?php echo e(ucwords($user->address)); ?></td>
                            <td><?php echo e(ucwords($user->city)); ?></td>
                            <td><?php echo e(ucwords($user->state)); ?></td>
                            <td><?php echo e(ucwords($user->country)); ?></td>
                            <td><?php echo e($user->branchcode); ?></td>
                            <td><?php echo $user->isAdmin() ? '<strong>HeadQuaters</strong>' : 'Branch Church'; ?></td>
                            <td><?php echo e($user->currency_symbol); ?></td>
                            <td>NULL <!--Mathew Ashimolowo --></td>
                            <td><a href="#" id="<?php echo e(route('branch.destroy',$user->id)); ?>" onclick="del(this);" class="btn btn-danger" /><span>delete<i class="fa fa-trash"></i></span></a</td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!--===================================================-->
        <!-- End Striped Table -->


    </div>
    <!--===================================================-->
    <!--End page content-->

</div>
<!--===================================================-->
<!--END CONTENT CONTAINER-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>