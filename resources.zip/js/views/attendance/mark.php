<?php ?>
<script>
/*$(document).ready(function(){
  //$('#mark-select').attr("disabled","disabled");
  $('#btn-mark').attr("disabled","disabled");
  $('#mark-date').change(function(){
    var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var value = $('#mark-date').val();
    var d = new Date(value);
    var day = days[d.getDay()];
    alert($('#mark-select').val());
    alert(day.toLowerCase()+' service');
    if(day == 'Wednesday' || day == ('Sunday') || day == ('Thursday')) {
      $('#mark-select').val(day.toLowerCase()+' service');
      $('#mark-select').removeAttr("disabled");
      alert($('#mark-select').val());
    }
    $('#mark-select').hide();
  });
});*/
</script>
