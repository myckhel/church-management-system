@foreach($all as $row)
  <p>{{$row->HOFNAME}}</p>
  <p>{{$row->HOLNAME}}</p>
  <p>{{$row->HOCITY}}</p>
  <p>{{$row->HOCOUNTRY}}</p>
  <p>{{$row->HOADDRESS}}</p>
@endforeach
